"""Bounded prompt-only trial; reuse the production adapter and preservation checks."""
import copy
import json
import os
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from prototypes.mixed_script.pipeline import (
    DEFAULT_INPUT, GeminiGenerator, PipelineError, occurrences, read_json,
    run_pipeline, save_result, is_odia_letter,
)

PROFILE={
    'self_reported_confidence': {'english':5,'odia':7,'scale':10},
    'preferred_explanation_language':'or',
    'odia_style':'simple conversational Odia; avoid unnecessary formal or literary wording',
    'english_style':'plain English technical phrases; avoid extra academic filler',
    'retain_english_phrases':[
        'voltage-controlled oscillator','direct frequency modulation',
        'control input','ideal linear model','VCO sensitivity','message voltage',
    ],
    'phrase_preference_status':'proposed for this hypothetical learner, not verified word familiarity',
    'switch_at':'natural phrase boundaries; keep Odia grammar and useful simple Odia connecting words',
    'mix_ratio':None,
}
POLICY='''Additional learner-selected language policy for both translation and mixed stages:
Use learner_language_profile from the supplied user JSON as style preferences.
Its 5/10 English and 7/10 Odia ratings are self-reported confidence, not measured
proficiency, an English/Odia word percentage, or proof of technical understanding.
Use simple conversational Odia for clause structure and ordinary connecting/helping
words. Do not replace easy Odia grammar words with random English filler.
Preserve each listed retain_english_phrases item verbatim in an English-labelled span
where it occurs in the ORIGINAL English, with exactly its original occurrence count.
These phrase preferences apply in addition to the original protected glossary/literals.
The phrases are proposed preferences for a hypothetical learner, not verified known
vocabulary. Use them without claiming the learner understands them.
Keep the ideal-model qualification, relationships, and claims intact. Never remove
an idea to make the language easier. Prefer phrase-level switching to isolated-word
substitution. Retain the same phrase text in the spoken version, except where the
original glossary/literal spoken expansion applies (e.g. VCO becomes V C O).
Do not add definitions, facts, analogies, numbers, extra commentary or a word-choice
rationale. Return only the original schema.''' 


def normalize_language_spans(stage, generated):
    repaired=copy.deepcopy(generated)
    changes=[]
    for sentence in repaired['sentences']:
        before=copy.deepcopy(sentence['spans'])
        after=[]
        for span in before:
            language=span['language']
            buffer=''
            for char in span['text']:
                target=('en' if char.isascii() and char.isalpha() else
                        'or' if is_odia_letter(char) else language)
                if target!=language and buffer:
                    after.append({'language':language,'text':buffer})
                    buffer=''
                language=target
                buffer+=char
            if buffer: after.append({'language':language,'text':buffer})
        assert ''.join(s['text'] for s in before)==''.join(s['text'] for s in after)
        if before!=after:
            changes.append({'stage':stage,'sentence_id':sentence['id'],
                            'before':before,'after':after,'text_unchanged':True})
        sentence['spans']=after
    return repaired,changes

class ProfileGenerator(GeminiGenerator):
    def generate(self,stage,request):
        request=copy.deepcopy(request)
        request['systemInstruction']['parts'].append({'text':POLICY})
        data=json.loads(request['contents'][0]['parts'][0]['text'])
        data['learner_language_profile']=PROFILE
        data['protected_glossary_counts_by_sentence']={
            s['id']:{t['english']:occurrences(s['english'],t['english'])
                     for t in data['original']['glossary']}
            for s in data['original']['sentences']
        }
        request['systemInstruction']['parts'].append({'text':
            'Respect protected_glossary_counts_by_sentence exactly, including zero counts. '
            'In s3 the carrier means the carrier SIGNAL; do not change it to carrier frequency. '
            'The phrase carrier frequency must appear only in s4. '
            'In s3 preserve instantaneous frequency once and amplitude once, alongside the '
            'ideal linear model qualification and unchanged equation. '
            'Do not add Odia duplicates of an already retained English phrase (e.g. direct). '
            'Perform a silent final check of each ID, phrase, glossary count, and language label.'})
        request['contents'][0]['parts'][0]['text']=json.dumps(data,ensure_ascii=False)
        print('Request stage:',stage,flush=True)
        result=super().generate(stage,request)
        raw_path=Path(f'work/vco-profile-en5-or7-attempt4-{stage}.raw.json')
        with raw_path.open('x',encoding='utf-8') as f:
            json.dump({'response':result,'call':self.calls[-1]},f,ensure_ascii=False,indent=2)
            f.write('\n')
        result,changes=normalize_language_spans(stage,result)
        self.span_repairs=getattr(self,'span_repairs',[])+changes
        print('Completed stage:',stage,'span-label repairs:',len(changes),flush=True)
        return result

def check_phrase_preferences(source,result):
    checks=[]
    glossary=source['glossary']
    for stage in ('translation','mixed'):
        for original,generated in zip(source['sentences'],result[stage]['sentences']):
            for phrase in PROFILE['retain_english_phrases']:
                expected=occurrences(original['english'],phrase)
                if not expected: continue
                spoken=phrase
                for term in glossary:
                    if term['english'] in phrase:
                        spoken=spoken.replace(term['english'],term['spoken_en'])
                actual=occurrences(generated['display_text'],phrase)
                actual_spoken=occurrences(generated['speech_text'],spoken)
                en_span=any(span['language']=='en' and phrase in span['text'] for span in generated['spans'])
                passed=actual==expected and actual_spoken==expected and en_span
                checks.append({'stage':stage,'sentence_id':original['id'],'phrase':phrase,
                               'expected':expected,'display_count':actual,'speech_count':actual_spoken,
                               'single_english_span':en_span,'passed':passed})
                if not passed:
                    raise PipelineError(f'Profile phrase constraint failed: {stage}/{original["id"]}/{phrase}')
    return checks

path=Path('work/vco-profile-en5-or7.json')
if path.exists():
    raise SystemExit('Output exists; choose another filename')
source=read_json(DEFAULT_INPUT)
try:
    generator=ProfileGenerator(os.environ.get('GEMINI_API_KEY',''),model='gemini-3.5-flash')
    result=run_pipeline(source,generator)
    result['language_profile_trial']={
        'profile':PROFILE,'additional_prompt':POLICY,
        'phrase_checks':check_phrase_preferences(source,result),
        'baseline_result':'work/vco-live.json',
        'human_readability_review':'pending',
        'span_label_repairs':generator.span_repairs,
        'earlier_attempts':[
            'Attempt 1: translation rejected for Latin text in an Odia span; candidate not retained.',
            'Attempt 2: translation rejected for adding carrier frequency in s3; raw response retained.',
            'Attempt 3: translation rejected for missing spoken acronym expansions; s4 also duplicated VCO. Raw response retained.',
        ],
    }
    save_result(result,path)
    print('Saved:',path)
    for stage in ('translation','mixed'):
        print(stage.upper())
        for sentence in result[stage]['sentences']:
            print(sentence['id']+': '+sentence['display_text'])
    print('SPEECH:',result['speech_script'])
except PipelineError as error:
    print('ERROR:',error,file=sys.stderr)
    raise SystemExit(2)
